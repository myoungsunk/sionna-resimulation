import hashlib,json,os,shutil,tarfile,zipfile
from pathlib import Path
root=Path('/home/KMS/OFFICE_CORRIDOR_TRANSFER_20261027_01a17631')
with tarfile.open(str(root/'P2_SOURCE_0686_COMPLETE.tar.gz')) as t:
    for item in t.getmembers():
        target=(root/item.name).resolve()
        assert os.path.commonpath([str(root),str(target)])==str(root)
        assert not item.issym() and not item.islnk() and not target.exists()
    t.extractall(str(root))
archive=root/'p2_artifacts.zip'
with archive.open('rb') as f:
    sha=hashlib.sha256()
    for chunk in iter(lambda:f.read(1024*1024),b''):sha.update(chunk)
assert sha.hexdigest()=='265b586283cbd3e50333530463ad1578a41bd0f7932b94b3728dfd87355dd4c1'
dest=root/'p2_artifacts';dest.mkdir()
with zipfile.ZipFile(str(archive)) as z:
    for item in z.infolist():
        target=(dest/item.filename).resolve()
        assert os.path.commonpath([str(dest),str(target)])==str(dest)
        assert (item.external_attr>>16)&0o170000 != 0o120000
    z.extractall(str(dest))
repo=root/'p2_source'
manifest=json.loads((repo/'research/EKF3_INDEPENDENT_20261013/P0_INPUT_MANIFEST.json').read_text())
original=Path('/home/KMS/DRIVE_SIM_POST_A23_SUPPLEMENT_20261010_01a12449/BLOCK_C')
known={a['path']:a['sha256'] for a in manifest['assets']}
paths={c[k] for c in manifest['cases'] for k in ['full_path','los_path','samples_path']}
paths.update(r['path'] for r in manifest['routes'])
receipts=[]
for name in sorted(paths):
    relative=name.split('/BLOCK_C/',1)[1]
    src=original/relative; dst=repo/name
    assert src.is_file() and not dst.exists(),name
    with src.open('rb') as f:
        sha=hashlib.sha256()
        for chunk in iter(lambda:f.read(1024*1024),b''):sha.update(chunk)
    digest=sha.hexdigest()
    if name in known:assert known[name]==digest,('ORIGINAL_RF_HASH_CHANGED',name)
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(str(src),str(dst))
    receipts.append({'path':name,'sha256':digest,'original':str(src),'registered':name in known})
with (root/'RF_STAGE_RECEIPT.json').open('x') as f:json.dump(receipts,f,indent=2)
print('P2_RUNTIME_STAGED',len(receipts),'RF/pose/timeline files; artifact SHA PASS',flush=True)
