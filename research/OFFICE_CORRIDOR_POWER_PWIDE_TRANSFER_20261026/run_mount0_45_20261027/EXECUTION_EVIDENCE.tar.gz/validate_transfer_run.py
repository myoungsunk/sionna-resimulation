import hashlib,json,sys,datetime
from pathlib import Path
import numpy as np
import pandas as pd
import joblib

root=Path('/run'); out=root/'validation'
out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2,default=lambda x:x.item() if hasattr(x,'item') else str(x))+'\n')
plan=json.loads((root/'EXECUTION_PLAN_02.json').read_text())
receipt=json.loads((root/'PIPELINE_RECEIPT.json').read_text())
assert receipt['status']=='ALL_REPLAYS_COMPLETED' and receipt['count']==21
expected={'_'.join(x) for x in plan['conditions']}
assert set(receipt['conditions'])==expected
all_scores=[]; checks=[]; max_score_error=0.;max_baseline_error=0.
for stem in sorted(expected):
    folder=root/'evaluation'/stem
    qa=json.loads((folder/(stem+'_TRANSFER_QA.json')).read_text())
    assert qa['technical']=='REPLAY_COMPLETED' and qa['baseline_parity']['status']=='PASS'
    assert qa['gate_status']=='EXPLORATORY_GT_PROXY'
    err=max(qa['baseline_parity']['absolute_errors'].values());assert err<1e-7
    max_baseline_error=max(max_baseline_error,err)
    assert qa['model_sha256']==sha(root/'office_models/OFFICE_TRAINED_MODELS.joblib')
    assert qa['control_origin']['status']=='PASS'
    assert qa['execution']['implementation_sha256']==plan['implementation_sha256']
    for name,digest in qa['outputs_sha256'].items():assert sha(folder/name)==digest,name
    scores=pd.read_csv(folder/(stem+'_TRANSFER_SCORES.csv'))
    series=pd.read_csv(folder/(stem+'_TRANSFER_SERIES.csv.gz'))
    assert set(scores.arm)==set(plan['arms']) and len(scores)==10
    assert not scores.duplicated(['case','channel','bias','arm']).any()
    assert set(series.arm)==set(plan['arms']) and len(series)==10*qa['n_steps']
    for arm,g in series.groupby('arm',sort=False):
        assert len(g)==qa['n_steps'] and np.all(np.diff(g.k)>0) and np.all(np.diff(g.t_s)>0)
        assert np.isfinite(g[['t_s','heading_error_deg','xy_error_m','heading_nees','heading_sigma_deg','gyro_bias_est_radps']].to_numpy(float)).all()
        s=g[g.t_s>=30]; row=scores.loc[scores.arm==arm].iloc[0]
        assert row['n']==len(s)
        calc={'heading_rmse_deg':np.sqrt(np.mean(s.heading_error_deg**2)),
              'heading_signed_bias_deg':s.heading_error_deg.mean(),
              'heading_q99_deg':np.quantile(abs(s.heading_error_deg),.99),
              'xy_rmse_m':np.sqrt(np.mean(s.xy_error_m**2)),
              'heading_nees':s.heading_nees.mean(),
              'heading_coverage95':np.mean(s.heading_nees<=3.84145882),
              'accept_frac':s.accepted.mean(),'range_only_frac':s.range_only.mean(),
              'gyro_bias_mean_radps':s.gyro_bias_est_radps.mean(),
              'office_power_out_of_range_frac':s.office_q_out_of_range.mean()}
        for key,val in calc.items():
            delta=abs(row[key]-val);max_score_error=max(max_score_error,delta)
            assert np.isclose(row[key],val,rtol=1e-10,atol=1e-10),(stem,arm,key,delta)
    checks.append({'condition':stem,'n_steps_per_arm':qa['n_steps'],'baseline_max_abs_error':err,'status':'PASS'})
    all_scores.append(scores)
scores=pd.concat(all_scores,ignore_index=True);assert len(scores)==210
scores.to_csv(out/'ALL_TRANSFER_SCORES.csv',index=False)
pairs=[]
for keys,g in scores.groupby(['case','channel','bias']):
    g=g.set_index('arm')
    for ref,cand,label in [('O_POWER','O_PWIDE','Office_PWIDE_vs_POWER'),('C_POWER','C_PWIDE','Corridor_PWIDE_vs_POWER'),('O_POWER','O_POWER_C_PWIDE','Cross_coupling_diagnostic')]:
        a=float(g.loc[ref,'heading_rmse_deg']);b=float(g.loc[cand,'heading_rmse_deg'])
        pairs.append(dict(zip(['case','channel','bias'],keys),comparison=label,reference_arm=ref,candidate_arm=cand,reference_rmse_deg=a,candidate_rmse_deg=b,delta_rmse_deg=b-a,relative_change_pct=100*(b/a-1),improved=b<a))
pairs=pd.DataFrame(pairs);pairs.to_csv(out/'PAIRED_COMPARISONS.csv',index=False)
# Each case is weighted equally here. Rows are correlated within route/scene.
summary=scores.groupby(['channel','bias','arm']).agg(n_cases=('case','size'),mean_case_heading_rmse_deg=('heading_rmse_deg','mean'),mean_case_nees=('heading_nees','mean'),mean_case_coverage95=('heading_coverage95','mean'),mean_case_xy_rmse_m=('xy_rmse_m','mean')).reset_index()
summary.to_csv(out/'CASE_MEAN_SCORES.csv',index=False)
sys.path.insert(0,str(root/'code'))
model=joblib.load(root/'office_models/OFFICE_TRAINED_MODELS.joblib')
save(out/'OFFICE_INNER_FOLD_AUDIT.json',model['RESIDUAL'].fold_audit)
train=json.loads((root/'office_models/OFFICE_TRAIN_QA.json').read_text())
report={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'conditions':21,'arms_per_condition':10,'score_rows':210,'source_training_rows':train['training_rows'],'source_mounts':train['source_mounts'],'baseline_strict_tolerance':1e-7,'max_baseline_abs_error':max_baseline_error,'max_recomputed_score_abs_error':max_score_error,'checks':checks,'gate_status':'EXPLORATORY_GT_PROXY','aggregation':'Arithmetic mean across seven cases per condition; not independent scenes or pooled sample RMSE','limitations':['No Office in-domain recursive performance evaluation','No gate calibration against actual Office recursive prior','Nominal initial state only; no perturbation factorial','Cross-coupled arm confounds teacher and training environment'],'outputs_sha256':{p.name:sha(p) for p in out.iterdir() if p.is_file()}}
save(out/'VALIDATION_RECEIPT.json',report)
print(json.dumps({k:report[k] for k in ['status','conditions','score_rows','max_baseline_abs_error','max_recomputed_score_abs_error']}))
print(summary[summary.arm.isin(['C_POWER','C_PWIDE','O_POWER','O_PWIDE'])].to_string(index=False))
print(pairs.groupby(['channel','bias','comparison']).improved.agg(['sum','count']).to_string())
