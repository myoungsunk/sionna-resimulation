import hashlib,json,shutil,tarfile,datetime
from pathlib import Path
root=Path('/home/KMS/OFFICE_CORRIDOR_TRANSFER_20261027_01a17631')
out=root/'delivery';out.mkdir(exist_ok=False)
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
with tarfile.open(str(out/'EXECUTION_EVIDENCE.tar.gz'),'w:gz') as t:
    for name in ['code','evaluation','office_models','corridor_models','frozen','validation']:
        for p in sorted((root/name).rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts:t.add(str(p),arcname=str(p.relative_to(root)))
    for pattern in ['*.json','*.log','*.py']:
        for p in sorted(root.glob(pattern)):t.add(str(p),arcname=p.name)
    t.add('/home/KMS/OFFICE_MOUNT_INPUTS_20261027_01a17631/Dockerfile.transfer',arcname='Dockerfile.transfer')
for p in (root/'validation').iterdir():
    if p.is_file():shutil.copy2(str(p),str(out/p.name))
for name in ['PIPELINE_RECEIPT.json','EXECUTION_PLAN_02.json','RF_STAGE_RECEIPT.json','tests.log']:
    shutil.copy2(str(root/name),str(out/name))
doc={'utc':datetime.datetime.utcnow().isoformat()+'Z','remote_root':str(root),'base_commit':'33e9849be8c5c62d45eb7e5ade7e85438b8fa247','mount_input_commit':'e4ccdd737fac9961261b7483095a79e515297111','p2_commit':'0686b23ceeefb696bc158b32b39f8077c564ef5d','source_audit_commit':'034e57a7209a3bd1bb8857b24fd85c64942e1258','p2_artifact':{'run_id':39376076166,'artifact_id':12243278686,'head_sha':'5dd61292538c3e95858c9050a60c4d4ddb03a214','zip_sha256':sha(root/'p2_artifacts.zip')},'raw_rf_resimulation':'NOT_RUN','original_evidence':'PRESERVED','setup_failure':'First freeze stopped at Git attribute-object availability. Objects hydrated and index refreshed; no physics, thresholds, source files or results changed. Successful full attempt is attempt02. Original failure receipts retained inside evidence archive.','contents':'All 21 time series, score tables, baseline traces, QA, trained models, frozen manifests, execution code/tests, commands/exit receipts/logs. Original RF and bank binaries remain at hashed original locations; not duplicated.','sha256':{p.name:sha(p) for p in out.iterdir() if p.is_file()}}
(out/'DELIVERY_RECEIPT.json').write_text(json.dumps(doc,indent=2)+'\n')
(out/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.is_file()))
print(json.dumps({'status':'PACKAGED','bytes':sum(p.stat().st_size for p in out.iterdir()),'files':len(list(out.iterdir()))}))
