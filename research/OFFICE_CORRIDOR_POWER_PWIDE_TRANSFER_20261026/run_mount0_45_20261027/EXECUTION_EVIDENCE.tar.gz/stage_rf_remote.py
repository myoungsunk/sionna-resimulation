import hashlib,json,os,shutil,tarfile,zipfile
from pathlib import Path
root=Path('/home/KMS/OFFICE_CORRIDOR_TRANSFER_20261027_01a17631')
repo=root/'p2_source'
manifest=json.loads((repo/'research/EKF3_INDEPENDENT_20261013/P0_INPUT_MANIFEST.json').read_text())
original=Path('/home/KMS/DRIVE_SIM_POST_A23_SUPPLEMENT_20261010_01a12449/BLOCK_C')
known={a['path']:a['sha256'] for a in manifest['assets'] if 'sha256' in a}
paths={c[k] for c in manifest['cases'] for k in ['full_path','los_path','samples_path']}
paths.update(r['path'] for r in manifest['routes'])
receipts=[]
for name in sorted(paths):
    relative=name.split('/BLOCK_C/',1)[1]
    src=original/relative; dst=repo/name
    assert src.is_file() and not dst.exists(),name
    with src.open('rb') as f:
        sha=hashlib.sha256()
        for chunk in iter(lambda:f.read(1024*1024),b''):sha.update(chunk)
    digest=sha.hexdigest()
    if name in known:assert known[name]==digest,('ORIGINAL_RF_HASH_CHANGED',name)
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(str(src),str(dst))
    receipts.append({'path':name,'sha256':digest,'original':str(src),'registered':name in known})
with (root/'RF_STAGE_RECEIPT.json').open('x') as f:json.dump(receipts,f,indent=2)
print('P2_RUNTIME_STAGED',len(receipts),'RF/pose/timeline files; artifact SHA PASS',flush=True)
