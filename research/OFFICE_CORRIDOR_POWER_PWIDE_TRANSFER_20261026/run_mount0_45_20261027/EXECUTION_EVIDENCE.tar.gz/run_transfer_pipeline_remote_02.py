import concurrent.futures,datetime,hashlib,json,os,subprocess,threading,time,traceback
from pathlib import Path
ROOT=Path('/home/KMS/OFFICE_CORRIDOR_TRANSFER_20261027_01a17631')
IMAGE='sha256:adad98bb4db40f5ad272dd4fbb0a9ffc8bdabb527e476d683b06aee7fcc5fe59'
CASES=['R2_aA_m45','R2_aA_m0','R2_aB_m0','R4_aA_m0','R4_aB_m0','R5_aA_m0','R5_aB_m0']
CONDITIONS=[(c,ch,b) for c in CASES for ch,b in [('full','B0'),('full','L2'),('los','B0')]]
ARMS=['C_POWER','C_PWIDE','O_POWER','O_PWIDE','O_POWER_C_PWIDE','O_PCIR',
      'O_POWER_G','O_PWIDE_G','O_POWER_STATE_G','O_PWIDE_STATE_G']
def write(name,doc):
    with (ROOT/name).open('w') as f:json.dump(doc,f,indent=2)
def read(path):return json.loads(Path(path).read_text())
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
base=['docker','run','--rm','--network','none','--user','1001:1001','--cpus','4','--memory','8g',
      '-e','PYTHONUNBUFFERED=1','-e','OMP_NUM_THREADS=1','-e','OPENBLAS_NUM_THREADS=1',
      '-e','GIT_CONFIG_COUNT=1','-e','GIT_CONFIG_KEY_0=safe.directory','-e','GIT_CONFIG_VALUE_0=/run/p2_source']
mounts=[(str(ROOT),'/run',False),(str(ROOT/'p2_source'),'/run/p2_source',True),
        ('/home/KMS/OFFICE_MOUNT_INPUTS_20261027_01a17631','/work',True),
        ('/home/KMS/OFFICE_M0_RF_20261026_01a17631','/rf0',True),
        ('/home/KMS/ROUTE_FULL_RF_20261019_R01','/rf45',True)]
for name in ['LP_plus45_bank.npz','LP_minus45_bank.npz']:
    mounts.append(('/home/KMS/SIONNA_NATIVE41_20260925_01a0d812/input/bank/'+name,'/run/'+name,True))
for src,dst,ro in mounts:
    base+=['--mount','type=bind,src='+src+',dst='+dst+(',readonly' if ro else '')]
base+=['--entrypoint','/opt/rt-env/bin/python',IMAGE]
def run(name,script,args):
    cmd=base+['/run/code/'+script]+args
    start=time.time()
    with (ROOT/('attempt02_'+name+'.log')).open('xb') as f:
        f.write((json.dumps({'argv':cmd,'started_epoch':start})+'\n').encode());f.flush()
        rc=subprocess.call(cmd,stdout=f,stderr=subprocess.STDOUT)
    write('attempt02_'+name+'_EXEC.json',{'exit_code':rc,'seconds':time.time()-start,'argv':cmd})
    print(json.dumps({'stage':name,'exit_code':rc,'seconds':round(time.time()-start,2)}),flush=True)
    if rc:raise RuntimeError('STOP_FAILED_STAGE:'+name)
def stem(c,ch,b):return c+'_'+ch+'_'+b
def frozen(c,ch,b):return ROOT/'frozen'/stem(c,ch,b)
common=['--target-checkout','/run/p2_source','--target-artifacts','/run/p2_artifacts']
def evaluate(condition):
    c,ch,b=condition;held=c.split('_')[0];name=stem(c,ch,b)
    f=read(frozen(c,ch,b)/'FREEZE_RECEIPT.json')
    control_case=next(x for x in CASES if x.startswith(held+'_'))
    control_path='/run/frozen/'+stem(control_case,'full','B0')+'/'+held+'_control_inputs.json'
    args=common+['--models','/run/office_models/OFFICE_TRAINED_MODELS.joblib',
        '--train-qa','/run/office_models/OFFICE_TRAIN_QA.json',
        '--source-qa','/work/PREPARED_FINAL/OFFICE_SOURCE_QA.json',
        '--corridor-models','/run/corridor_models/'+held+'/'+held+'_C_PWIDE.joblib',
        '--corridor-qa','/run/corridor_models/'+held+'/'+held+'_C_PWIDE_QA.json',
        '--corridor-input-manifest',control_path,'--input-manifest',f['target_manifest'],
        '--input-manifest-sha256',f['target_manifest_sha256'],'--case',c,'--channel',ch,'--bias',b,
        '--exploratory-gates','--out','/run/evaluation/'+name]
    run('replay_'+name,'office_transfer_cli.py',['replay']+args)
    qa=read(ROOT/'evaluation'/name/(name+'_TRANSFER_QA.json'))
    assert qa['technical']=='REPLAY_COMPLETED' and qa['baseline_parity']['status']=='PASS'
    assert qa['gate_status']=='EXPLORATORY_GT_PROXY'
    return name
try:
    assert not (ROOT/'EXECUTION_PLAN_02.json').exists(),'NO_IMPLICIT_RERUN'
    write('EXECUTION_PLAN_02.json',{'created_utc':datetime.datetime.utcnow().isoformat()+'Z',
        'implementation_base':'e4ccdd737fac9961261b7483095a79e515297111',
        'source_mounts':[0,45],'source_rows':1150,'conditions':CONDITIONS,'arms':ARMS,
        'initial':'Frozen nominal initial state and controls; no additional perturbation experiment',
        'baseline_tolerance_strict_lt':1e-7,'gate_interpretation':'EXPLORATORY_GT_PROXY',
        'raw_rf_resimulation':'NOT_AUTHORIZED_OR_RUN','runtime_image':IMAGE,
        'max_parallel_replays':4,'max_allocated_cpus':16,
        'implementation_sha256':{p.name:sha(p) for p in (ROOT/'code').glob('*.py')}})
    for c,ch,b in CONDITIONS:
        name=stem(c,ch,b)
        run('freeze_'+name,'freeze_input_contract.py',common+['--held',c.split('_')[0],
            '--case',c,'--channel',ch,'--bias',b,'--out','/run/frozen/'+name])
    for held in ['R2','R4','R5']:
        c=next(c for c in CASES if c.startswith(held+'_'))
        f=read(frozen(c,'full','B0')/'FREEZE_RECEIPT.json')
        run('fit_corridor_'+held,'office_transfer_cli.py',['fit-corridor']+common+['--held',held,
            '--input-manifest',f['control_manifest'],'--input-manifest-sha256',f['control_manifest_sha256'],
            '--out','/run/corridor_models/'+held])
    completed=[evaluate(CONDITIONS[0])]
    write('PROGRESS.json',{'status':'FIRST_BASELINE_PASS','completed':completed,'total':len(CONDITIONS)})
    # Only dispatch independent conditions after the first real-RF baseline passes.
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        jobs={pool.submit(evaluate,c):c for c in CONDITIONS[1:]}
        for future in concurrent.futures.as_completed(jobs):
            try:completed.append(future.result())
            except Exception:
                for pending in jobs:pending.cancel()
                raise
            write('PROGRESS.json',{'status':'RUNNING','completed':completed,'total':len(CONDITIONS)})
    write('PIPELINE_RECEIPT.json',{'status':'ALL_REPLAYS_COMPLETED','conditions':completed,
        'count':len(completed),'expected_score_rows':len(CONDITIONS)*len(ARMS),
        'source_mounts':[0,45],'gate_status':'EXPLORATORY_GT_PROXY','runtime_image':IMAGE})
except Exception as exc:
    write('PIPELINE_FAILURE_02.json',{'status':'FAILED_STOP','reason':repr(exc),'traceback':traceback.format_exc()})
    raise
