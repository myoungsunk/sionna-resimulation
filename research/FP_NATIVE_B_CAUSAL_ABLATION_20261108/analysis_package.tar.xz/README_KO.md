# Native–B 2×2 폐루프 원인 분해 실행 패키지

## 상태

- 저장 원본 비교 및 폐루프 추적 행별 집계: **검토 완료** (`RESULTS_KO.md`).
- 추가 재귀 NN/BN/NB/BB 실험: **코드 작성, 문법 검사 및 합성 자기검사 완료 / 실제 RF 데이터 실행 NOT_RUN**.
- 원래 W0 parity, 기존 B parity, 신뢰도·상호작용 평가: **코드상 강제 검증이며 실제 PASS 미확정**.

## 파일

- `fp_ns_ablation.py`: 실제 원본 SourceFFD를 재사용하는 NN/BN/NB/BB 2×2 자연 게이트 + NN 게이트 고정 + 동일 prior 즉시 갱신 분석. truth는 재귀 실행 후에만 읽음.
- `stored_audit.py`: **이미 저장된 CSV만** 이용해 native↔B tap 변화, W0/BB RMSE, K1/K2 피드백 통계 재집계. 개발용 전체 FFD bank 불필요.
- `RESULTS_KO.md`: 현재 확인한 사실, 의심 메커니즘, 아직 확인되지 않은 주장.
- `SELFTEST.json`: 합성 QA 결과.

## 실행 커맨드

GitHub의 고정 커밋을 체크아웃한 뒤 아래 명령을 사용할 수 있습니다. 기존 결과 디렉터리는 수정하지 않습니다.

```bash
python stored_audit.py --repo /path/to/sionna-resimulation --out /path/to/NEW_STORED_AUDIT.json
python fp_ns_ablation.py --selftest
python fp_ns_ablation.py --repo /path/to/sionna-resimulation --out /path/to/NEW_CAUSAL_RUN
```

### 필수 입력 조건

`fp_ns_ablation.py`는 고정 커밋 `c141839...`의 `research/FP_SC_RECOVERY_R0_R5_20261107/r45.py`를 임포트합니다. **이전 R45 실행에 사용한 실제 원본 입력을 동일한 캐시/경로에 유지해야 합니다.** 필요 파일은 `r45.py`의 `data()`/`cached()`가 SHA 확인하도록 정의한 각 경로의 `online.npz` 및 `evaluator.npz`와 `R45_sources`의 FFD banks (`LP_plus45_bank.npz`, `LP_minus45_bank.npz`) 및 source files입니다. 단순 Git LFS pointer로는 실행되지 않습니다.

`R45_RUN_001/R2_TRACE.npz`, `R4_TRACE.npz`, `R5_TRACE.npz`도 실제 NPZ로 접근 가능해야 이전 B 폐루프와 바이트 독립적 수치 parity를 확인합니다.

잘못되거나 없는 입력에는 우회/대체 모델을 쓰지 않고 오류를 내도록 설계했습니다. 입력을 새로 만들거나 SourceFFD 결과를 임의 보간하지 않습니다. 기존 원본/보고서를 덮어쓰지 않으며 신규 결과 디렉터리가 존재하면 실행이 거절됩니다.

## 판정 기준

1. `NN` 전체 시점이 `on['trace_x/P/prior/Pprior/h/H/K/mask']` 및 원본 W0와 정규화 오차 1e-10 이내 일치.
2. `BB`가 `R45_RUN_001/*_TRACE.npz`의 B 상태·공분산·게이트와 같은 기준으로 일치.
3. native/B detector가 같은 tap을 선택한 시점에서는 z=[range,s]가 동일해야 함.
4. NN 고정 K의 즉시 갱신에서 `Δx_BB = K_r Δr + K_s Δs`, 오차 1e-12 이내.
5. 독립 진화 2×2의 **MSE 차이**와 상호작용 항, 경로별 RMSE, Heading/XY 95% 포함률, NEES3, 수용 마스크, 동일 입력시점의 상태 괴리 보고.
6. `NN` gate를 고정한 재귀 실험과 각자 자체 gate의 성능 비교. 모든 실제 결과의 셀별 계보를 남김.

실행 후 `RESULTS.json`의 상태가 `PASS_IMPLEMENTER_SELF_CHECK`가 되어야 하며, 그 상태도 **독립 감사 통과나 새로운 환경 일반화는 뜻하지 않습니다.** `FAILURE.json`이 생성되면 해당 실패를 먼저 원인 조사해야 합니다.

## 혁신 분해 추가 검증

각 arm의 최신 예측 모델은 prior에 따라 다시 평가되지만 `muMB`는 고정되어 있으므로 다음 항등식을 행별 수치로 확인합니다.

`nu_BB - nu_NN = (z_BB - z_NN) - (h_BB - h_NN)`

같은 현재 관측 (`z_BB=z_NN`)에서도 혁신이 다르면, 그 차이는 과거 다른 입력으로 형성된 prior에서 계산한 **관측모델 예측 차이**입니다. `RESULTS.json`의 `innovation_accounting`에 직접 관측 차이, 상태 피드백 예측 차이, 최종 혁신 차이의 RMS와 항등식 오차가 기록됩니다. 이는 원인을 무조건 range 또는 s로 분류하지 않으며, 자연 폐루프 진화의 진단입니다.
