# Native vs B / 폐루프 오염 메커니즘 — 저장 증거 재검산

**고정 데이터:** `sionna-resimulation` 커밋 `c141839093d1a2e4a76f91eea632cb6467163e28`, R2·R4·R5 × B0 × Full × seed10. 3,136시점. 이 문서는 **실제 저장된 CSV와 과거 W0 결과를 검토하고 재집계한 조사**이며, NN/BN/NB/BB 네 구성의 새로운 재귀 계산을 실행했다는 의미가 아니다. 새로운 2×2 계산을 수행하는 스크립트 `fp_ns_ablation.py`는 별도로 제공한다.

## A. 검출기 교체가 실제로 무엇을 바꾸었나

- native: 강한 RX 포트를 결정한 뒤 해당 포트의 30% 최초 에지.
- B: 각 RX의 자기 peak 30% 최초 에지 중 빠른 에지.
- 정확히 **572/3,136 (18.24%)** 행에서 다른 tap. 572건 모두 **B가 native보다 앞선 tap**, 이동량 평균 1.39860 tap, 최대 16 tap.
- native 정상→B 오류 **229건**, native 오류→B 정상 **233건**. 모두 정상 1,904건, 모두 오류 770건.
- Native-LoS 참조 tap 기준 평균 절대 오류: native 0.367666 tap, B 0.321747 tap. **정답 tap 근접도가 좋아져도 폐루프 성능이 좋아지지 않는 실제 반례.**

## B. Full 폐루프 기존 W0(native)와 B 무복원 비교

| 경로 | native Heading RMSE | B Heading RMSE | native XY RMSE | B XY RMSE |
|---|---:|---:|---:|---:|
| R2 (979) | 1.050834° | 2.161582° | 7.8738 cm | 18.0274 cm |
| R4 (742) | 1.310486° | 1.262285° | 6.7696 cm | 10.6225 cm |
| R5 (1415) | 0.729052° | 1.141056° | 5.5079 cm | 8.9220 cm |
| 전체 (3136, 제곱오차 가중 합산) | **0.995438°** | **1.556641°** | **6.6246 cm** | **12.8090 cm** |

Native 자료: R2는 `POST_S3_PROPOSER_20261104/R2_EXTENSION/FULL_002/NATURAL_SUMMARY.csv`의 `A/S2` (MB_VAR W0), R4·R5는 `MBVAR_PRR_001_20261103/S1/runs/EVAL_001/SCORES_PER_SEED.csv`의 W0. B는 `FP_SC_RECOVERY_R0_R5_20261107/R45_RUN_001/R5_METRICS.csv`. 두 조건은 동일 파형·입력/초기조건·모델의 폐루프 결과이나, 아래와 같은 구성 요소별 교체 결과는 기존에 없음.

## C. 피드백으로 새 경보가 만들어지는 직접 관찰

R5 재귀 행별 기록에서 **B 기준과 K1 거리 전용**을 비교했다.

- K1 거리복원 정상 훼손 **738건**, 정확 복구 **359건**.
- 정상 훼손 중 **591건 (80.1%)**은 **동일 시점에 B 기준에서는 경보가 없던 시점**이다. 과거 선택과 갱신으로 상태가 달라져 예측 P 중심이 달라지면서 새 경보가 생긴 것이다.
- 738건 정상 훼손 중 **730건 (98.9%)**은 K1의 실제 shadow 게이트를 통과했다.
- 738건 정상 훼손에서 K1의 P 중심과 B의 P 중심 사이 절대 차이는 평균 **10.39 cm**.
- **현재 두 필터가 정확히 같은 range와 s를 받는 1,912시점**에서도, **1,910시점은 사전 갱신 이력으로 두 필터 추정 상태가 달랐고**, 위치 추정 상태의 평균 XY 거리 차이가 **12.95 cm**였다. 같은 시점 수용 여부가 달랐던 경우는 24건.
- K2 거리 전용에서도 정상 훼손 **1,099건**, 이 중 B 기준에서 원래 경보 없었던 시점 **915건**, 수용된 정상 훼손 **1,096건**이었다.

이 집계는 **과거 오정정 → 상태 이동 → 다음 P 중심 이동 → 경보·관측 선택 변화 → 추가 오정정**의 재귀 경로가 실제 저장 결과에 존재함을 보여준다. 그러나 각 순환 고리의 독립적인 기여율이나 range vs s 원인 비중을 확정해 주지는 않는다.

## D. 왜 구분해야 하는가

### 1. native→B (FP 검출기 변경)

B의 tap 선택은 **현재 수신 CIR 자체**에서 결정되므로, 예측 상태 P를 직접 사용하지 않는다. 따라서 *native→B* 악화를 그대로 '자기 예측으로 선택한 FP' 때문이라고 해석할 수 없다. 대신 현재 관측의 range와 s가 **동시에 바뀌고**, 고정된 native 보정항 `muMB/muBASE`와 R 아래서 **상태·공분산·게이트에 반복 전달되는 경로**를 검증해야 한다.

### 2. B→K1/K2 (예측 P 기반 복원)

이 단계에서만 **상태 → P 중심 → 후보 선택 → 관측 갱신 → 새 상태**의 자기참조 선택이 추가된다. 예측과 가까운 tap을 고르는 것은 참조 tap의 근거와 다르다. 원래 정상 B가 P 밖에 있으면 잘못된 tap으로 교체하고, 같은 선택 관측으로 shadow gate까지 갱신할 수 있다. 불확실성을 충분히 반영하지 않고 갱신을 수용하면 관측 사실이 아닌 선택의 일관성에 의해 P가 축소될 수 있다. **수용된 정상 훼손 다수와 상태 괴리는 이 경로와 정합적이나, 독립 개입으로 고리별 효과를 측정해야 한다.**

## E. 다음 필수 실험: 인과 2×2, 게이트·피드백 분해

NN: native range+native s, BN: B range+native s, NB: native range+B s, BB: B range+B s.

동일 고정 RF/IMU/odometry, x0/P0, Q, R, muMB/muBASE 및 SourceFFD에서 네 구성을 **각자 own-state main+shadow gate**로 실행한다. 비물리적 혼합 BN/NB는 **원인 분해를 위한 counterfactual**로만 이용한다.

세 평가를 분리한다.

1. **동일 prior 1회 갱신**: native W0 prior/h/H/K 및 게이트를 공통으로 두어 `K[:,range]*Δr`, `K[:,s]*Δs`의 자세 갱신량을 측정. 이 층에서는 고정 K 선형성이므로 상호작용항은 수학적으로 0이어야 한다.
2. **native 수용 마스크 고정 폐루프**: 추정 상태·선형화는 각자 진행하되 NN 게이트만 공통으로 사용. 자연 게이트와 비교해 gate 경로 기여를 진단.
3. **각자 자연 게이트 폐루프**: 경로별/전체 Heading·XY RMSE/NEES/coverage, 수용된 관측 수 및 게이트 불일치, 동일 현재 관측 시점의 장기 상태차를 측정.

MSE 기준 상호작용: `I = MSE(BB) - MSE(BN) - MSE(NB) + MSE(NN)`. **RMSE를 직접 더하고 빼지 말 것.** gate 통과 변화와 불확실성 보정 미스매치, 누적 상태 이동, 선형화 지점 변경을 구별해 해석해야 한다.

### 주장 경계

- **네 구성 실데이터 재귀 실행: 이 환경에서는 NOT_RUN.** 원본 `online.npz/evaluator.npz`와 SourceFFD bank가 로컬 런타임에 없어 실행할 수 없다. 기존 GitHub 결과를 네 구성의 결과로 오인하지 않는다.
- **합성 QA: PASS** (`fp_ns_ablation.py --selftest`). `NN/BN/NB/BB` 실제 성능 또는 관측 메커니즘을 입증하는 것이 아니다.
- 자가 검산/원노출 seed10이고 독립 환경 반복 또는 새로운 시뮬레이션은 없다. '참조 tap'은 Native-LoS 검출기의 operational index이며 물리적 최초 도달 시간의 ground truth와 동일하다고 가정하지 않는다.

## 고정 출처

- [R0–R5 결과 루트](https://github.com/myoungsunk/sionna-resimulation/tree/c141839093d1a2e4a76f91eea632cb6467163e28/research/FP_SC_RECOVERY_R0_R5_20261107)
- [R5 행별 폐루프](https://github.com/myoungsunk/sionna-resimulation/blob/c141839093d1a2e4a76f91eea632cb6467163e28/research/FP_SC_RECOVERY_R0_R5_20261107/R45_RUN_001/R5_ROWS.csv)
- [R5 실험 구현](https://github.com/myoungsunk/sionna-resimulation/blob/c141839093d1a2e4a76f91eea632cb6467163e28/research/FP_SC_RECOVERY_R0_R5_20261107/r45.py)
- [원래 W0 online.py](https://github.com/myoungsunk/sionna-resimulation/blob/c141839093d1a2e4a76f91eea632cb6467163e28/research/FP_SC_RECOVERY_R0_R5_20261107/R45_sources/research/MBVAR_PRR_001_20261103/S1/online.py)
- [native vs B detector 원본: T0/T1](https://github.com/myoungsunk/sionna-resimulation/blob/c141839093d1a2e4a76f91eea632cb6467163e28/research/FP_SC_MISSED_ONSET_T0T1_20261106/T1_INTERPRETATION_KO.md)
