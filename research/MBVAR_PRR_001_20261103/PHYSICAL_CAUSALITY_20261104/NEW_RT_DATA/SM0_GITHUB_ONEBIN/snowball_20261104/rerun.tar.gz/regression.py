from pathlib import Path
import json,sys,hashlib,numpy as np
base=next(Path('/src').rglob('native_rt_batch.py'))
sys.path.insert(0,str(base.parent))
import native_rt_batch as b
ref=np.load(b.ROOT/b.BLOCK/'H_LoS_R4_aB_m0.npy',mmap_mode='r')
cfg,_=b.preflight('/bank')
lim=cfg['qa']['original_archive_C00_LoS_max_rel_l2']
rows=[]
for k in cfg['pose_ids']:
 d=Path('/previous')/f'C00_DIRECT-{k}-r0'
 m=json.loads((d/'MANIFEST.json').read_text());p=d/'RAW_COMPLEX_H_AND_PATHS.npz'
 assert m['file_sha256'][p.name]==b.h(p)
 z=np.load(p);h=z['H_complex_rx_rx_tx'];old=np.linalg.norm(h[:,:,0]-ref[k,:,:,0])/np.linalg.norm(ref[k,:,:,0])
 assert abs(old-m['direct_reference_relative_L2'])<1e-12 and old>lim
 assert (z['path_counts']==1).all()
 new=np.array([b.archive_channel(a[:,:,None],np.array([t]),f) for a,t,f in zip(z['path_coefficient'],z['path_delay_s'],z['frequencies_hz'])])
 err=np.linalg.norm(new[:,:,0]-ref[k,:,:,0])/np.linalg.norm(ref[k,:,:,0])
 assert err<=lim
 rows.append([k,old,err])
q=dict(rows=rows,threshold=lim,base_commit='c727703e2fc99d304fb97712220a7336b894d73e',patched_source_sha256=b.h(base),lock_sha256=b.h(b.LOCK))
Path('/out/offline_regression.json').write_text(json.dumps(q,indent=2))
print(q,flush=True)
