import os,sys,subprocess,json,concurrent.futures,pathlib
out=pathlib.Path('/out')
base=next(pathlib.Path('/src/research').rglob('native_rt_batch.py'))
agg=base.with_name('native_rt_aggregate.py')
arms=['C00_DIRECT','C01_FLOOR','C10_PARALLEL_PLATE','C11_OBLIQUE_PLATE']
poses=[194,234,500,525]
assert set(os.sched_getaffinity(0))==set(range(32))
print('CPUSET', sorted(os.sched_getaffinity(0)),flush=True)
budget=dict(status='USER_APPROVED_FOR_CPU_RT',science_class='USER_AUTHORIZED_NONINDEPENDENT_EXPLORATORY',max_solver_calls=8224,max_job_wall_seconds=1200,pose_ids=poses,arm_ids=arms,authorization='Explicit user request for Snowball PR33 in this chat; no GitHub dispatch')
(out/'BUDGET.json').write_text(json.dumps(budget,indent=2))
subprocess.run([sys.executable,base,'--static','--bank','/bank'],check=True)
def qa(stage):
 cmd=[sys.executable,agg,'--stage',stage,'--root',out,'--out',out]
 if stage=='paired':cmd+=['--c00-root',out]
 rc=subprocess.run(cmd).returncode
 (out/(stage+'_KEY_LIST.csv')).write_bytes((out/'QA_KEY_LIST.csv').read_bytes())
 return rc
for arm in arms:
 for rep in range(2):
  def job(p):
   key=f'{arm}-{p}-r{rep}'
   cmd=[sys.executable,'-u',base,'--execute','--arm',arm,'--pose',str(p),'--repeat',str(rep),'--out',out/key,'--bank','/bank','--token','I_AUTHORIZE_CPU_RT_STAGE','--budget',out/'BUDGET.json','--max-calls','257','--wall-seconds','1200']
   if arm!=arms[0]:cmd+=['--c00-qa',out/'C00_QA.json']
   with (out/(key+'.log')).open('xb') as log:
    return subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
  with concurrent.futures.ThreadPoolExecutor(4) as pool:codes=list(pool.map(job,poses))
  print(arm,rep,codes,flush=True)
  if any(codes):
   qa('c00' if arm==arms[0] else 'paired')
   sys.exit(1)
 if arm==arms[0] and qa('c00'):sys.exit(1)
sys.exit(qa('paired'))

