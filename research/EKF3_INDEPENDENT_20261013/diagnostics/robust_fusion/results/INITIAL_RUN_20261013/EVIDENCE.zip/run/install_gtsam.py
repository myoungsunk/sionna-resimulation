from pathlib import Path
import sys,subprocess,json,time
r=Path('D:/SLAM_bot/artifacts/EKF3_ROBUST_FUSION_20261013');env=r/'gtsam_env';cmds=[];start=time.time()
with (r/'GTSAM_INSTALL.log').open('w') as f:
 for cmd in ([sys.executable,'-m','venv',str(env)],[str(env/'Scripts/python.exe'),'-m','pip','install','--disable-pip-version-check','numpy==1.26.4','scipy==1.15.3','gtsam==4.2','pytest==8.4.2']):
  p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT);cmds.append(dict(command=cmd,exit_code=p.returncode))
  if p.returncode:break
(r/'GTSAM_INSTALL_RECEIPT.json').write_text(json.dumps(dict(commands=cmds,elapsed_s=time.time()-start),indent=2));sys.exit(p.returncode)
