from pathlib import Path
import json,hashlib,zipfile,shutil,datetime,subprocess
r=Path('D:/SLAM_bot/artifacts/EKF3_ROBUST_FUSION_20261013');repo=Path('D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/checkout');code=repo/'research/EKF3_INDEPENDENT_20261013/diagnostics/robust_fusion';out=code/'results/INITIAL_RUN_20261013'
out.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((r/'M1_FULL/MANIFEST.json').read_text())['rows']==504
assert json.loads((r/'M0/M0_PARITY.json').read_text())['compared']==504
for stage,name,hashkey in [('M0','MANIFEST.json','sha256'),('M1_FULL','MANIFEST.json','output_sha256'),('M1_SMOKE_FIXED','MANIFEST.json','output_sha256'),('STRUCTURE','RF_RESIDUAL_STRUCTURE_GATE.json','output_sha256')]:
 j=json.loads((r/stage/name).read_text())
 for n,h in j[hashkey].items():assert sha(r/stage/n)==h,(stage,n)
for rel in ['M0/M0_PARITY.json','STRUCTURE/RF_RESIDUAL_STRUCTURE_GATE.json','STRUCTURE/RF_TRAINING_MOMENTS.json','GTSAM_PREFLIGHT_KEY_ONLY/GTSAM_PREFLIGHT.json','COVARIANCE_CHECK.json','FINAL_TEST_RECEIPT.json','AUDIT_KO.md','IMPLEMENTATION_NOTES.json','PROCESS_CLOSURE.json']:
 shutil.copy2(r/rel,out/Path(rel).name)
for f in (r/'EVALUATION').iterdir():shutil.copy2(f,out/f.name)
for model in ('M0','M1_FULL'):
 shutil.copy2(r/model/('M0_METRICS.csv' if model=='M0' else 'M1_METRICS.csv'),out/('M0_METRICS.csv' if model=='M0' else 'M1_METRICS.csv'))
with zipfile.ZipFile(out/'EVIDENCE.zip','w',zipfile.ZIP_DEFLATED) as z:
 for dirname in ['M0','M1_FULL','M1_SMOKE_FIXED','M1_SMOKE','M1_TESTS','STRUCTURE','OBSERVABILITY','GTSAM_PREFLIGHT','GTSAM_PREFLIGHT_KEY_ONLY','EVALUATION','PROCESS_LOGS']:
  for f in (r/dirname).rglob('*'):
   if f.is_file():z.write(f,'run/'+str(f.relative_to(r)).replace('\\','/'))
 for f in r.iterdir():
  if f.is_file() and f.suffix in ('.json','.log','.md','.txt','.py'):z.write(f,'run/'+f.name)
 for f in code.rglob('*'):
  if f.is_file() and not any(x in f.parts for x in ('results','__pycache__','.pytest_cache')):z.write(f,'source/'+str(f.relative_to(code)).replace('\\','/'))
(out/'.gitattributes').write_text('* -text\n')
(out/'RESULT_MANIFEST.json').write_text(json.dumps(dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),status='M0_M1_COMPLETED_M2_BLOCKED',scientific_PASS=False,sha256={f.name:sha(f) for f in out.iterdir() if f.is_file() and f.name!='RESULT_MANIFEST.json'}),indent=2))
print(out);print('zip bytes',(out/'EVIDENCE.zip').stat().st_size)
