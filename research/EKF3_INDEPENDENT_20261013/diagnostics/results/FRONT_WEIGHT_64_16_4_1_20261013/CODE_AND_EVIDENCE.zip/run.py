import sys,json,csv,hashlib,time
from pathlib import Path
import numpy as np
R=Path('D:/SLAM_bot/artifacts/EKF3_FRONT_DENSE_64_16_4_1_20261013');repo=Path('D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/checkout');d=repo/'research/EKF3_INDEPENDENT_20261013/diagnostics';sys.path.insert(0,str(d))
from d6_d9_common import OBS,check_inputs,checked_path,spectrum
from run_d5_regimes import timelines
from d10_d14_core import extract_cir_methods,signed_power_ratio,write_rows
from front_dense import features,self_test
self_test()
src=Path('D:/SLAM_bot/artifacts/EKF3_D10_D14_4c0ab22/D11_FULL');meta=json.loads((src/'D11_MANIFEST.json').read_text())
for f,h in meta['sha256'].items():assert hashlib.sha256((src/f).read_bytes()).hexdigest()==h
old={(r['case'],r['channel'],int(r['sample_index']),r['method']):r for r in csv.DictReader((src/'D11_ONLINE_WINDOW_S.csv').open())}
p0=check_inputs();freq=spectrum(p0);routes=timelines(p0);data={};online=[];start=time.time();mx=0
for case in p0['cases']:
 t,truth,pids=routes[case['route']];samples=json.loads(checked_path(p0,case['samples_path']).read_text('utf8'));pos={int(r['pose_id']):i for i,r in enumerate(samples)}
 for ch in ('los','full'):
  H=np.load(checked_path(p0,case[ch+'_path']),mmap_mode='r');valid=np.flatnonzero(t>=30)
  for begin in range(0,len(valid),64):
   ids=valid[begin:begin+64];cir=OBS.cir_batch(np.asarray(H[[pos[int(pids[i])] for i in ids]],complex)[...,0]);fp=OBS.first_path_batch(cir,float(freq[1]-freq[0]))
   for j,i in enumerate(ids):
    values,e=extract_cir_methods(cir[j],fp_index=int(fp['index'][j]));p=abs(cir[j])**2;k=e['window_begin'];n=e['window_width_taps'];o=old[case['id'],ch,int(i),'W2_ADAPTIVE_CROSS'];err=abs(values['W2_ADAPTIVE_CROSS']-float(o['s_value']));mx=max(mx,err);assert err<=1e-12
    v={m:values[m] for m in ('W0_FP','W0_CO_FP','W1_EARLY3','W2_ADAPTIVE_CROSS')};v['FIXED4']=signed_power_ratio(p[k:k+4].sum(0))
    new,extra=features(np.asarray(H[pos[int(pids[i])]],complex)[...,0],cir[j],k,e['selected_reference_rx']);v.update(new)
    assert abs(v['CO_SINGLE']-v['W0_CO_FP'])<=1e-12
    online.append(dict(case=case['id'],channel=ch,sample_index=int(i),**new,**extra))
    data[case['id'],int(i),ch]=dict(v=v,n=n,shift=k-int(fp['index'][j]),port=e['selected_reference_rx'],det=e['cross_rise_detected'],onset=e['cross_rise_onset'],route=case['route'],weight0=float(p[k].sum()/p[k:k+4].sum()))
 print(case['id'],'done',flush=True)
rows=[]
for (case,i,ch),a in data.items():
 if ch!='full':continue
 b=data[case,i,'los'];r=dict(case=case,route=a['route'],sample_index=i,full_width=a['n'],los_width=b['n'],full_shift=a['shift'],los_shift=b['shift'],full_detected=a['det'],los_detected=b['det'],port_disagree=int(a['port']!=b['port']),full_fp_weight=a['weight0'],los_fp_weight=b['weight0'])
 for m in a['v']:r[m]=a['v'][m]-b['v'][m]
 rows.append(r)
write_rows(R/'PAIRED_DECOMPOSITION.csv',rows)
summary=[]
for group in ['ALL','R2','R4','R5','neither_cut','full_only_cut','los_only_cut','both_cut','same_start','changed_start']:
 subset=[r for r in rows if group=='ALL' or r['route']==group or (group=='neither_cut' and r['full_width']==4 and r['los_width']==4) or (group=='full_only_cut' and r['full_width']<4 and r['los_width']==4) or (group=='los_only_cut' and r['full_width']==4 and r['los_width']<4) or (group=='both_cut' and r['full_width']<4 and r['los_width']<4) or (group=='same_start' and r['full_shift']==0 and r['los_shift']==0) or (group=='changed_start' and (r['full_shift']!=0 or r['los_shift']!=0))]
 if not subset:continue
 z={m:np.array([r[m] for r in subset]) for m in a['v']};out=dict(group=group,n=len(subset))
 for m,x in z.items():out[m+'_rms']=float(np.sqrt(np.mean(x*x)))
 for label,x,y in [('start','W0_FP','W0_CO_FP'),('integrate','W0_CO_FP','FIXED4'),('stop','FIXED4','W2_ADAPTIVE_CROSS')]:out[label+'_mse_delta']=float(np.mean(z[y]**2-z[x]**2))
 summary.append(out)
write_rows(R/'SUMMARY.csv',summary)
stats={}
for ch in ('full','los'):
 v=[x for (c,i,h),x in data.items() if h==ch];stats[ch]=dict(n=len(v),detected=sum(x['det'] for x in v),effective_cut=sum(x['n']<4 for x in v),width_counts={str(k):sum(x['n']==k for x in v) for k in range(1,5)},shift_counts={str(k):sum(x['shift']==k for x in v) for k in sorted(set(x['shift'] for x in v))},mean_firsttap_energy_weight=float(np.mean([x['weight0'] for x in v])))
(R/'RECEIPT.json').write_text(json.dumps(dict(parity_max_abs=mx,elapsed_s=time.time()-start,config=meta['config'],stats=stats,source_manifest_sha256=hashlib.sha256((src/'D11_MANIFEST.json').read_bytes()).hexdigest(),scientific_PASS=False),indent=2));print(json.dumps(stats),flush=True)

write_rows(R/'ONLINE_FEATURES.csv',online)
