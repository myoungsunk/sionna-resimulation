import sys,subprocess,time,json,datetime
from pathlib import Path
r=Path('D:/SLAM_bot/artifacts/EKF3_D15_VALIDATE_20261013');repo=Path('D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/checkout');d=repo/'research/EKF3_INDEPENDENT_20261013/diagnostics'
name=sys.argv[1];p2='D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/DIAGNOSTICS_701b8d2/P2_DOWNLOAD/P2_OUT'
if name=='OBS':cmd=[sys.executable,str(d/'d15_dense_observations.py'),'--out',str(r/'OBS')]
else:
 cmd=[sys.executable,str(d/'d15_dense_los_validation.py'),'--out',str(r/name),'--d11',str(r/'OBS'),'--p2-dir',p2]
 if name=='BASELINE':cmd+=['--baseline-only']
 if name=='SMOKE':cmd+=['--cases','R2_aA_m0','--stride','20','--max-eval-per-case','10']
t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (r/(name+'.log')).open('w',encoding='utf8') as f:p=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
(r/(name+'_RECEIPT.json')).write_text(json.dumps(dict(command=cmd,start=start,elapsed_s=time.monotonic()-t,exit_code=p.returncode),indent=2));sys.exit(p.returncode)
