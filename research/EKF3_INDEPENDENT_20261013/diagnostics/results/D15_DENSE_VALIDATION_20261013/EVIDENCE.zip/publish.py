import json,hashlib,zipfile,subprocess,shutil
from pathlib import Path
repo=Path('D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/checkout');r=Path('D:/SLAM_bot/artifacts/EKF3_D15_VALIDATE_20261013');d=repo/'research/EKF3_INDEPENDENT_20261013/diagnostics'
for name,stage in [('OBS','D11'),('BASELINE','D12')]:
 j=json.loads((r/name/(stage+'_MANIFEST.json')).read_text())
 for f,h in j['sha256'].items():assert hashlib.sha256((r/name/f).read_bytes()).hexdigest()==h
# Preserve the exact executed runner source; final code differs only in module documentation.
snap=r/'EXECUTED_SOURCE';snap.mkdir(exist_ok=True)
for name,original,stage in [('d15_dense_observations.py','d11_adaptive_window.py','OBS'),('d15_dense_los_validation.py','d12_los_window_model.py','BASELINE')]:
 s=(d/name).read_text();o=(d/original).read_text();s=o[:o.index('"""',3)+3]+s[s.index('"""',3)+3:];(snap/name).write_text(s,encoding='utf8')
 manifest=json.loads((r/stage/('D11_MANIFEST.json' if stage=='OBS' else 'D12_MANIFEST.json')).read_text())
 assert hashlib.sha256((snap/name).read_bytes()).hexdigest()==manifest['script_sha256'][name]
shutil.copy2(d/'d15_dense_core.py',snap/'d15_dense_core.py')
summary={'code_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'tests':'28_PASS','P0':'39_ASSETS_PASS','P2_parity':'24804_A_C_COMPARISONS_PASS_1e-8','dense_rms':.14758267816439086,'LOS_model':'BLOCKED_FFD_BANK_UNAVAILABLE','heading_sensitivity':'NOT_RUN','candidate_gate':'NOT_RUN','recursive_EKF':'NOT_RUN','scientific_PASS':False,'download_block':'Automatic approval review rejected bank retrieval, stated reason: blocked by policy','provenance':'Executed runner snapshots hash-match manifests; code commit only changes their module documentation after execution.'}
(r/'VALIDATION_RECEIPT.json').write_text(json.dumps(summary,indent=2))
out=d/'results/D15_DENSE_VALIDATION_20261013';out.mkdir(exist_ok=False)
with zipfile.ZipFile(out/'EVIDENCE.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in r.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(r))
for f in ('VALIDATION_RECEIPT.json','TEST.log','OBS_RECEIPT.json','BASELINE_RECEIPT.json','PROCESS_CLOSURE.json'):shutil.copy2(r/f,out/f)
shutil.copy2(d/'D15_DENSE_RUN_KO.md',out/'SUMMARY_KO.md')
(out/'SHA256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()},indent=2))
print('Evidence verified; packaged bytes',sum(p.stat().st_size for p in out.iterdir()))
