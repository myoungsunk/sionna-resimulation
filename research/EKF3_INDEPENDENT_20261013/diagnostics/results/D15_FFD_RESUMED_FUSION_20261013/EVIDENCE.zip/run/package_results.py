from pathlib import Path
import json,csv,math,hashlib,zipfile,shutil,subprocess,datetime
r=Path('D:/SLAM_bot/artifacts/EKF3_D15_FFD_RESUME_20261013')
repo=Path('D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/checkout');d=repo/'research/EKF3_INDEPENDENT_20261013/diagnostics'
out=d/'results/D15_FFD_RESUMED_FUSION_20261013';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=json.loads((r/'VERIFICATION.json').read_text())
for stage,tag in [('SMOKE','D12'),('FULL','D12'),('FUSION_SMOKE','D14'),('FUSION_FULL','D14')]:
 assert json.loads((r/(stage+'_RECEIPT.json')).read_text())['exit_code']==0
 p=r/stage;m=json.loads((p/(tag+'_MANIFEST.json')).read_text())
 for name,h in m['sha256'].items():assert sha(p/name)==h,(stage,name)
 checks[stage]={'hashes_verified':len(m['sha256'])}
rows=list(csv.DictReader((r/'FUSION_FULL/D14_RECURSIVE_ABLATION.csv').open()))
assert len(rows)==112
keys=('case','channel','arm','seed','level','bias_mode','sigma_heading_deg')
b={tuple(q[k] for k in keys):q for q in rows if q['fusion_arm']=='F0_ORIGINAL'}
for q in rows:
 if q['fusion_arm']=='F1_DENSE_EKF' and q['arm'] in ('D0','B'):
  old=b[tuple(q[k] for k in keys)]
  assert all(q[k]==v for k,v in old.items() if k not in ('fusion_arm','window_method'))
checks['D0_B_feature_invariance']='PASS_EXACT_ALL_28_PAIRS'
par=json.loads((r/'FUSION_FULL/D14_BASELINE_PARITY.json').read_text());assert par['compared']==par['expected']==56
checks['full_D5_parity']=par
summary=[]
for channel in ('los','full'):
 for arm in ('D0','A','B','C'):
  for variant in ('F0_ORIGINAL','F1_DENSE_EKF'):
   a=[x for x in rows if x['channel']==channel and x['arm']==arm and x['fusion_arm']==variant];n=sum(int(x['n']) for x in a)
   s=dict(channel=channel,arm=arm,variant=variant,n=n)
   for metric in ('heading_rmse_deg','xy_rmse_m','mean_pose_NEES','mean_heading_NEES','pose95','heading95'):
    exponent=2 if 'rmse' in metric else 1
    s[metric]=(sum(int(x['n'])*float(x[metric])**exponent for x in a)/n)**(1/exponent)
   summary.append(s)
with (out/'FUSION_POOLED_METRICS.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=summary[0]);w.writeheader();w.writerows(summary)
(out/'VERIFICATION.json').write_text(json.dumps(checks,indent=2))
for stage,files in {'FULL':['D12_WINDOW_GATES.json','D12_WINDOW_SUMMARY.csv','D12_MANIFEST.json'],'FUSION_FULL':['D14_BASELINE_PARITY.json','D14_RECURSIVE_ABLATION.csv','D14_DELTA_VS_F0.csv','D14_MANIFEST.json']}.items():
 for name in files:shutil.copy2(r/stage/name,out/name)
for name in ('BANK_RECEIPT.json','FULL_RECEIPT.json','SMOKE_RECEIPT.json','FUSION_FULL_RECEIPT.json','FUSION_SMOKE_RECEIPT.json','PROCESS_CLOSURE.json','AUDIT.md'):
 if (r/name).exists():shutil.copy2(r/name,out/name)
with zipfile.ZipFile(out/'EVIDENCE.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in r.rglob('*'):
  if f.is_file():z.write(f,'run/'+str(f.relative_to(r)).replace('\\','/'))
 for f in sorted(d.glob('d15*.py')):z.write(f,'source/'+f.name)
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'execution_base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'scientific_PASS':False,'fusion_scope':'7 cases x LoS/Full x D0/A/B/C x original/dense; seed 0, noise_pair level 1, initial heading std 5 deg, B_OLD/R0 frozen','aggregation':'pooled sample-weighted descriptive RMSE/means; samples are not independent replications','sha256':{f.name:sha(f) for f in out.iterdir() if f.is_file()}}
(out/'RESULT_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(summary,indent=2));print('OUT',out)
