"""Fixed front weights and local dense time sampling; no oracle inputs."""
import numpy as np
def adaptive_weights(energy):
    energy=np.asarray(energy,float)
    if energy.ndim!=1 or not np.isfinite(energy).all() or np.any(energy<=0):raise ValueError('Invalid tap energy')
    w=np.minimum(1.,energy[0]/energy)
    return w/w.sum()

def dense_cir(h, factor=4):
    n=h.shape[-2]; win=.5-.5*np.cos(2*np.pi*np.arange(n)/(n-1))
    return np.fft.ifft(h*win[:,None],n=4*n*factor,axis=-2)*n*factor

def features(h, coarse, start, port):
    p=abs(coarse)**2
    fine=dense_cir(h)
    # Scale-aware FFT roundoff bound also covers analytically zero taps.
    bound=64*np.finfo(float).eps*max(1.,np.log2(len(fine)))*np.max(abs(coarse))
    if np.max(abs(fine[::4]-coarse))>bound:raise RuntimeError('Dense/coarse complex parity failed')
    k=int(start); threshold=.3*np.max(abs(coarse[:,port])); fallback=False
    lo=max(0,k-1)*4; hi=k*4
    if k>0 and abs(fine[lo,port])<threshold<=abs(fine[hi,port]):
        hits=np.flatnonzero(abs(fine[lo:hi+1,port])>=threshold);q=lo+int(hits[0])
    else:q=hi;fallback=True
    result={};metadata={}
    for label,powers,idx,step in [('CO',p,k,1),('DENSE',abs(fine)**2,q,4)]:
        ids=idx+step*np.arange(4)
        if ids[-1]>=len(powers):raise ValueError('Window outside CIR')
        a=powers[ids];energy=a.sum(axis=1)
        if np.any(energy<=0):raise ValueError('Zero-power tap')
        s=(a[:,0]-a[:,1])/energy
        weights=adaptive_weights(energy)
        for z,w in enumerate(weights):metadata[label+'_weight_'+str(z)]=float(w)
        result[label+'_SINGLE']=float(s[0])
        result[label+'_FRONT_S']=float(weights@s)
        result[label+'_FRONT_POWER']=float((weights@(a[:,0]-a[:,1]))/(weights@energy))
    return result,dict(**metadata,refined_index_original_grid=q/4,shift_original_taps=q/4-k,fallback=int(fallback))

def self_test():
    n=257;h=np.ones((n,2),complex);h[:,1]*=.5
    c=dense_cir(h,1);v,e=features(h,c,1,0)
    assert all(abs(x-.6)<1e-12 for x in v.values())
    rng=np.random.default_rng(29);h=rng.normal(size=(n,2))+1j*rng.normal(size=(n,2));c=dense_cir(h,1)
    assert np.allclose(dense_cir(h)[::4],c,rtol=1e-12,atol=1e-12)
    w=adaptive_weights([1,64,4,.25])
    assert np.isclose(w[1]/w[0],1/64) and w[3]==w[0]
    assert np.allclose(w,adaptive_weights(np.array([1,64,4,.25])*100))
    assert np.isclose(w.sum(),1)
    print('SELF_TEST_PASS: proportional ports, complex grid parity, adaptive amplitude-squared compensation')
if __name__=='__main__':self_test()
