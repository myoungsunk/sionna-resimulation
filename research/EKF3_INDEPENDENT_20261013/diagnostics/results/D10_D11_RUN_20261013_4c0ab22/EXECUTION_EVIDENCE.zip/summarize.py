import csv,json,hashlib,subprocess,datetime
from pathlib import Path
R=Path('D:/SLAM_bot/artifacts/EKF3_D10_D14_4c0ab22');repo=Path('D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/checkout')
rows=list(csv.DictReader((R/'D11_FULL/D11_CASE_SUMMARY.csv').open()))
by={(r['method'],r['group']):r for r in rows}
ratios={g:float(by['W2_ADAPTIVE_CROSS',g]['rms_full_minus_los_s'])/float(by['W0_FP',g]['rms_full_minus_los_s']) for g in ('ALL_SCENE','R2','R4','R5')}
print(json.dumps(ratios))
text='''# D10–D11 실제 실행 결과 및 후속 단계 중단

실행 코드: `4c0ab22f262d319ca2da77a38cf90a41be62bfc7`. 설정과 허용치 변경 없음.

- 합성 단위 테스트: 11 PASS.
- P0: 39개 자산, 7조건, 3경로 SHA/shape/pose 검사 PASS.
- D11 단일 조건 smoke 및 전체 7조건 LoS/Full 실행 완료. 원본 FP 관측 parity 검사 통과.
- 평가 구간 t >= 30 s: 방법당 6,201개 대응 관측. 시점은 독립 반복 실험이 아님.

| 경로 | FP RMS | Adaptive RMS | Adaptive/FP |
|---|---:|---:|---:|
'''
for g in ('ALL_SCENE','R2','R4','R5'):
 text+=f"| {g} | {float(by['W0_FP',g]['rms_full_minus_los_s']):.8f} | {float(by['W2_ADAPTIVE_CROSS',g]['rms_full_minus_los_s']):.8f} | {ratios[g]:.6f} |\n"
text+='''
1차 목표인 Full–LoS 편파 차이 감소는 실패했다. 전체 RMS 약 19.9% 증가, 세 경로 및 7개 조건 모두 악화. D12 gate 중 RMS 비 <=0.95, 최소 2경로 개선, 최악 경로 비 <=1.05 요건을 이미 만족하지 못한다. 이는 D11 결과에서 확인한 필수조건 실패이며, 미실행 D12를 실행 완료/FAIL로 기록하지 않는다.

D12 관측모델/P2 parity, D13 bias 교차실험, D14 재귀 융합은 NOT_RUN. 사용자가 지정한 1차 가설 우선 순서에 따라 후속 실행을 중단했다. failed-gate 우회나 사후 threshold 조정 없음.

추가 대조군: W0_CO_FP RMS=0.16204233으로 FP 대비 약 5.2% 감소했으나, 이는 기준 포트의 단일 tap 변경 효과다. Adaptive 적분의 성공이나 관측모델/Heading 성능 검증을 뜻하지 않는다. W1 3-tap RMS=0.19916596, W3 template=0.30573415, W4 total energy=0.37636556.

`unresolved_at_fp_unidentifiable`은 모든 관측에 기록된 원리적 가능성 플래그이며, 실제 첫 tap 오염 탐지율로 해석할 수 없다. window 관련 부가 열은 모든 방법 행에 같은 adaptive 진단값이 복제되므로 방법별 실제 window 길이로 해석하지 않는다.

과학적 판정: `scientific_PASS=false`. 단일 동결 RF scene의 탐색 결과다. 기존 코드와 동결 입력/결과는 수정하지 않았다.
'''
(R/'SUMMARY_KO.md').write_text(text,encoding='utf8')
(R/'PRIMARY_GATE.json').write_text(json.dumps(dict(source_commit='4c0ab22f262d319ca2da77a38cf90a41be62bfc7',D11_primary_hypothesis='NOT_SUPPORTED',ratios=ratios,D12='NOT_RUN',D13='NOT_RUN',D14='NOT_RUN',scientific_PASS=False),indent=2))
