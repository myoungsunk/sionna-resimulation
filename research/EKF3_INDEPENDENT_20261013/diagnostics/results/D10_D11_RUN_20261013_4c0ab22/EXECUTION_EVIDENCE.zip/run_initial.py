import subprocess,sys,json,time,datetime
from pathlib import Path
R=Path('D:/SLAM_bot/artifacts/EKF3_D10_D14_4c0ab22');repo=Path('D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/checkout');d=repo/'research/EKF3_INDEPENDENT_20261013/diagnostics'
steps=[('TEST',[sys.executable,'-m','pytest','-q',str(d/'test_d10_d14.py')]),('P0',[sys.executable,str(d.parent/'p0_verify_inputs.py')]),('D11_SMOKE',[sys.executable,str(d/'d11_adaptive_window.py'),'--out',str(R/'D11_SMOKE'),'--cases','R2_aA_m0']),('D11_FULL',[sys.executable,str(d/'d11_adaptive_window.py'),'--out',str(R/'D11_FULL')])]
rec=[]
for name,cmd in steps:
 t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat();print('START',name,flush=True)
 with (R/(name+'.log')).open('w',encoding='utf8') as f:p=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
 rec.append(dict(stage=name,command=cmd,started=start,elapsed_s=time.monotonic()-t,exit_code=p.returncode));(R/'EXECUTION_RECEIPT.json').write_text(json.dumps(rec,indent=2));print('END',name,p.returncode,round(time.monotonic()-t,2),flush=True)
 if p.returncode:sys.exit(p.returncode)
