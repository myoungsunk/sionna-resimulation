import json,hashlib,zipfile,shutil
from pathlib import Path
R=Path('D:/SLAM_bot/artifacts/EKF3_D10_D14_4c0ab22');repo=Path('D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/checkout')
for st in ('D11_SMOKE','D11_FULL','D10_FULL'):
 stage='D11' if st.startswith('D11') else 'D10';p=R/st;j=json.loads((p/(stage+'_MANIFEST.json')).read_text('utf8'))
 for f,h in j['sha256'].items():assert hashlib.sha256((p/f).read_bytes()).hexdigest()==h,(st,f)
closure=json.loads((R/'PROCESS_CLOSURE.json').read_text('utf-8-sig'))
assert closure['ok']
s=(R/'SUMMARY_KO.md').read_text('utf8')+'\nD10: 기존 D7 온라인/평가 자료와 D2 heading gain 자료를 연결한 6종 CSV 생성 완료(exit 0). D10/D11 manifest의 산출물 SHA-256 재검증 통과. 실행 명령·시간·종료 코드는 동봉 receipt 참조.\n'
(R/'SUMMARY_KO.md').write_text(s,encoding='utf8')
out=repo/'research/EKF3_INDEPENDENT_20261013/diagnostics/results/D10_D11_RUN_20261013_4c0ab22';out.mkdir(exist_ok=False)
with zipfile.ZipFile(out/'EXECUTION_EVIDENCE.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in R.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(R))
for name in ('SUMMARY_KO.md','PRIMARY_GATE.json','EXECUTION_RECEIPT.json','D10_EXECUTION_RECEIPT.json','PROCESS_CLOSURE.json'):
 shutil.copy2(R/name,out/name)
shutil.copy2(R/'D11_FULL/D11_CASE_SUMMARY.csv',out/'D11_CASE_SUMMARY.csv')
(out/'SHA256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()},indent=2))
print('Verified manifests; publication bytes',sum(p.stat().st_size for p in out.iterdir()))
print(json.dumps(closure)[:2500])
