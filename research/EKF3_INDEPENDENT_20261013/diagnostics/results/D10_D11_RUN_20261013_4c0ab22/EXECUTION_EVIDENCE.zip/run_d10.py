import subprocess,sys,json,time,datetime
from pathlib import Path
R=Path('D:/SLAM_bot/artifacts/EKF3_D10_D14_4c0ab22');repo=Path('D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/checkout');d=repo/'research/EKF3_INDEPENDENT_20261013/diagnostics'
cmd=[sys.executable,str(d/'d10_multipath_correlations.py'),'--d7','D:/SLAM_bot/artifacts/EKF3_D6_D9_PARITY_FIX/D7_FULL','--out',str(R/'D10_FULL'),'--d2',str(d/'results/AUDITED_RUN_20261013_701b8d2/OUTPUT_D0_D4_SEED0/D2_HEADING_DECOMPOSITION.csv.gz')]
t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (R/'D10_FULL.log').open('w',encoding='utf8') as f:p=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
(R/'D10_EXECUTION_RECEIPT.json').write_text(json.dumps(dict(command=cmd,started=start,elapsed_s=time.monotonic()-t,exit_code=p.returncode),indent=2));sys.exit(p.returncode)
