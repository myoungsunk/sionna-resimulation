import subprocess,sys,json,time,datetime
from pathlib import Path
R=Path('D:/SLAM_bot/artifacts/EKF3_D6_D9_6e40ec9'); repo=Path('D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/checkout'); d=repo/'research/EKF3_INDEPENDENT_20261013/diagnostics/d9_quality_aware_fusion.py'
common=['--d7',str(R/'D7_FULL'),'--d8',str(R/'D8_FULL'),'--seeds','0','--levels','1','--conditions','noise_pair']
steps=[('D9_UT_BIAS_SMOKE',['--cases','R2_aA_m0','--methods','F0_ORIGINAL','F1_UT','F2_BIAS4','--save-trace']),('D9_LOS_QUALITY_SMOKE',['--cases','R2_aA_m0','--channels','los','--methods','F0_ORIGINAL','F1_UT','F2_BIAS4','F3_CIR_R','F4_UT_CIR_R','F5_BIAS4_CIR_R','F6_UT_BIAS4_CIR_R','--save-trace']),('D9_7CASE_UT_BIAS_SEED0_LEVEL1',['--methods','F0_ORIGINAL','F1_UT','F2_BIAS4'])]
rec=[]
for name,args in steps:
 cmd=[sys.executable,str(d),'--out',str(R/name),*common,*args]; start=datetime.datetime.now(datetime.timezone.utc).isoformat(); tick=time.monotonic(); print('START',name,flush=True)
 with (R/(name+'.log')).open('w',encoding='utf8') as f:p=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
 rec.append(dict(stage=name,command=cmd,started=start,elapsed_s=time.monotonic()-tick,exit_code=p.returncode));(R/'D9_EXECUTION_RECEIPT.json').write_text(json.dumps(rec,indent=2));print('END',name,p.returncode,round(time.monotonic()-tick,2),flush=True)
 if p.returncode:sys.exit(p.returncode)
