# D6–D9 재감사 및 실제 실행 결과

기준 커밋: 6e40ec919fba1637db1c2019d2745d6a1113ff81. 2026-10-13 로컬 Python 3.10 / NumPy 2.2.4. 원본 checkout은 변경하지 않았다. Snowball은 사용하지 않았다.

## 최종 판정

- code_audit=REDIRECT, execution_ready=false, scientific_PASS=false.
- 기존 import/JSON 저장/보정별 목표/prior-post/원본 해시 및 요청 셀 parity 수정은 실제 실행에서 확인했다.
- 전체 실험 완료는 아니다. 사전 중단 규칙에 따라 D9 7조건 확장 parity 실패에서 종료했다. 임계값을 변경하지 않았다.

## 실제 실행

| 단계 | 범위 | 결과 |
|---|---|---|
| 단위·계약 테스트 | test_d6_d9.py + test_d6_d9_contracts.py | 17 PASS |
| P0 무결성 | 39 assets / 7 cases / 3 routes | PASS |
| D6-0 기존 D5 trace | 1512 파일, 4536 지표 행 | 해시·재계산 PASS |
| D6-1 MC | 60 조건, 각 5000 표본 | 실행 완료 |
| D6-2 Bias | R2_aA_m0, seed0, level1, step trace 포함 | smoke 완료 |
| D7 | 7 RF 조건 LoS/Full, 기본 설정 | 추출·receiver parity 완료 |
| D8 | 3 route 홀드아웃, Q0–Q3, B_OLD 및 Full E1 | 실행 완료, 9개 gate 중 1 PASS |
| D9 F0 | R2_aA_m0, seed0, level1, noise_pair, LoS/Full | 8/8 기준 셀 일치 |
| D9 UT/Bias | 같은 R2 조건, F0/F1/F2 | smoke 완료 |
| D9 LoS 품질 | 같은 R2 LoS 조건, F0–F6 | smoke 완료 |
| D9 7조건 확장 | seed0/level1/noise_pair/LoS+Full/F0–F2 | parity FAIL, exit 1 |

D9 확장 실패 셀: R5_aB_m0 / full / noise_pair / level1 / seed0 / B_OLD / A. mean_pose_NEES 절대차 3.5364204720167436e-7 > 1e-8. 수치오차인지 구현차이인지 미확정. 결과 CSV와 PASS manifest를 게시하기 전 fail-closed로 중단했다. 별도 `D9_7CASE_UT_BIAS_SEED0_LEVEL1.log`에 traceback을 보존했다.

## 핵심 관측

1. RF 없는 10m 직진, 초기 yaw 표준편차20도에서 95% 위치타원 포함률: EKF45.78%, UT95.80%, 정확한 모멘트 타원93.38%. Monte Carlo 진행방향 분산은 EKF 예측의64.99배였다. 순수 비선형성 성분을 지지하는 제한된 통제 실험이며 실제 경로 개선 증명은 아니다.
2. D8에서 R2/LoS/B_OLD만 품질 gate PASS. 모든 Full RF 조건은 FAIL. Q4는 보정 증빙 부재로 미실행했고 학습 Rsr를 적용하지 않았다.
3. R2 LoS Joint C의 F0→F3: Heading RMSE0.232503→0.080178도, 위치RMSE0.026632→0.023402m, mean pose NEES2.94115→15.05266, pose95 포함률0.960193→0.268999. RMSE 감소에도 일관성이 크게 악화해 최종 융합 개선으로 승인할 수 없다.
4. D6 M4 Full RF smoke에서 EKF3→BIAS4 Heading RMSE5.5679→7.5399도, 위치RMSE0.4845→0.9248m. Bias 상태 추가만으로 개선된다는 주장을 지지하지 않는다. 한 경로·한 seed이며 일반화하지 않는다.

## 재감사 잔여 지적

1. E1 중첩 홀드아웃: D7은 각 관측 경로의 동결 E1 LORO 계수로 레이블을 생성한다. D8 외부 평가 경로가 R2일 때 학습용 R4/R5 E1 계수의 기존 보정 학습에는 R2가 포함된다. 동결 보정 탐색 결과는 보존하되 전체 파이프라인 홀드아웃 검증으로 승인하지 않는다. 근거: d7_cir_multipath_audit.py164–168, d8_polarization_quality.py290–312 및389.
2. 자동 H3 판정은 Q0 대비 Q3만 사용한다. s_fp만 쓰는 Q1 대비 추가 정보라는 가설을 판정하려면 Q1 비교가 필요하다. 근거: d6_d9_verdict.py103–119. 해당 자동 verdict는 실행하지 않았으며 H3 일반화 결론은 INCONCLUSIVE다.
3. D9 7조건 F0 parity 실제 실패. 원인을 먼저 확인해야 하며 사후 허용치 완화로 PASS를 만들지 않는다.

## 증빙과 보존

EXECUTION_RECEIPT.json, D9_EXECUTION_RECEIPT.json: 실행 명령, UTC, elapsed, exit code. 각 stage 폴더: CSV 및 code/output SHA-256 manifest. 완료 manifest11개의 출력 해시를 재검증했다. REVIEW_EXECUTION_SUMMARY.json: 통합 판정. 단위테스트와 P0 결과는 본 세션 도구 출력에서 확인했고 통합 요약에 기록했다.

원본 파일·RF·보정 계수·기존 결과와 Git 작업트리는 변경하지 않았다. 결과는 이 로컬 폴더에 추가했다. GitHub 신규 커밋/업로드는 하지 않았다. 관리 작업 두 개 모두 자연 종료했고 finish 후 프로세스·supervisor·job 부재를 확인했다.

다음 작업은 7조건 parity 실패 원인 규명, E1 외부 split 정합, H3 Q1 비교 및 RF 불확실성 calibration 보완이다. 전체 multi-seed 확대는 그 후에 수행한다.
