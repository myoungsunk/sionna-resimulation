import csv,json,hashlib
from pathlib import Path
R=Path('D:/SLAM_bot/artifacts/EKF3_D6_D9_6e40ec9')
def read(p):
    with p.open(encoding='utf8') as f:return list(csv.DictReader(f))
summary={'commit':'6e40ec919fba1637db1c2019d2745d6a1113ff81','unit_tests':{'passed':17,'failed':0},'P0':{'status':'PASS','assets':39,'cases':7,'routes':3},'code_audit':'REDIRECT','scientific_PASS':False,'audit_findings':['E1 nested heldout calibration contamination: do not admit learned E1 quality as heldout validated','Automatic H3 verdict lacks Q1 comparison; manual claim boundary required']}
summary['manifests']=[]
for p in sorted(R.glob('*/*MANIFEST.json')):
    j=json.loads(p.read_text(encoding='utf8')); ok=all(hashlib.sha256((p.parent/f).read_bytes()).hexdigest()==s for f,s in j['sha256'].items())
    summary['manifests'].append({'stage':p.parent.name,'execution_commit':j.get('execution_commit'),'outputs_hash_match':ok})
p=R/'D8_FULL/D8_FOLD_MODELS.json'
if p.exists():
    j=json.loads(p.read_text(encoding='utf8'))
    summary['D8_gates']=[dict(route=r,channel=c,range_model=m,gate=v['q3_heldout_gate']['status']) for r,rf in j['folds'].items() for c,cf in rf.items() for m,v in cf['range_models'].items()]
    rows=read(R/'D8_FULL/D8_CIR_QUALITY_VALIDATION.csv')
    summary['D8_scores']=rows
p=R/'BIAS_SMOKE/D6_BIAS_ROUTE_ABLATION.csv'
if p.exists():summary['D6_bias_smoke']=read(p)
p=R/'D9_F0_SMOKE/D9_F0_D5_PARITY.json'
if p.exists():summary['D9_F0_parity']=json.loads(p.read_text())
(R/'REVIEW_EXECUTION_SUMMARY.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('D6_bias_smoke','D8_scores')},indent=2))
