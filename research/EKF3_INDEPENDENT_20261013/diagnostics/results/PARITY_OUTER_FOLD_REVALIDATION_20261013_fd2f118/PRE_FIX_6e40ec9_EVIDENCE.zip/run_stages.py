import subprocess,sys,json,time,datetime
from pathlib import Path
ROOT=Path('D:/SLAM_bot/artifacts/EKF3_D6_D9_6e40ec9')
REPO=Path('D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/checkout')
D=REPO/'research/EKF3_INDEPENDENT_20261013/diagnostics'
ROOT.mkdir(exist_ok=True)
steps=[
('TRACE_SMOKE','d6_d5_trace_audit.py',['--local-root','D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/DIAGNOSTICS_701b8d2','--cases','R2_aA_m0']),
('TRACE_FULL','d6_d5_trace_audit.py',['--local-root','D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/DIAGNOSTICS_701b8d2']),
('BIAS_SMOKE','d6_bias_observability.py',['--cases','R2_aA_m0','--seeds','0','--levels','1','--save-step-trace']),
('D7_SMOKE','d7_cir_multipath_audit.py',['--cases','R2_aA_m0']),
('D7_FULL','d7_cir_multipath_audit.py',[]),
('D8_FULL','d8_polarization_quality.py',['--d7',str(ROOT/'D7_FULL')]),
('D9_F0_SMOKE','d9_quality_aware_fusion.py',['--d7',str(ROOT/'D7_FULL'),'--d8',str(ROOT/'D8_FULL'),'--cases','R2_aA_m0','--seeds','0','--levels','1','--conditions','noise_pair','--methods','F0_ORIGINAL','--save-trace'])]
receipts=[]
for name,script,args in steps:
    cmd=[sys.executable,str(D/script),'--out',str(ROOT/name),*args]
    started=datetime.datetime.now(datetime.timezone.utc).isoformat(); tick=time.monotonic()
    print('START',name,flush=True)
    with (ROOT/(name+'.log')).open('w',encoding='utf8') as f:
        p=subprocess.run(cmd,cwd=REPO,stdout=f,stderr=subprocess.STDOUT)
    receipts.append(dict(stage=name,command=cmd,started=started,elapsed_s=time.monotonic()-tick,exit_code=p.returncode))
    (ROOT/'EXECUTION_RECEIPT.json').write_text(json.dumps(receipts,indent=2),encoding='utf8')
    print('END',name,p.returncode,round(time.monotonic()-tick,2),flush=True)
    if p.returncode: sys.exit(p.returncode)
