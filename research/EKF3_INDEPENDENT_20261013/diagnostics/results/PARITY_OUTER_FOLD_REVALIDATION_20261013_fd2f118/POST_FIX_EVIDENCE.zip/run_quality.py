import subprocess,sys,time,json,datetime
from pathlib import Path
r=Path('D:/SLAM_bot/artifacts/EKF3_D6_D9_PARITY_FIX');repo=Path('D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/checkout');d=repo/'research/EKF3_INDEPENDENT_20261013/diagnostics';old=Path('D:/SLAM_bot/artifacts/EKF3_D6_D9_6e40ec9')
steps=[('D9_LOS_QUALITY','d9_quality_aware_fusion.py',['--d7',str(r/'D7_FULL'),'--d8',str(r/'D8_FULL'),'--cases','R2_aA_m0','--channels','los','--seeds','0','--levels','1','--conditions','noise_pair','--methods','F0_ORIGINAL','F1_UT','F2_BIAS4','F3_CIR_R','F4_UT_CIR_R','F5_BIAS4_CIR_R','F6_UT_BIAS4_CIR_R','--save-trace']),('VERDICT','d6_d9_verdict.py',['--d6-mc',str(old/'MC_FULL'),'--d6-bias',str(old/'BIAS_SMOKE'),'--d6-d5-trace',str(old/'TRACE_FULL'),'--d7',str(r/'D7_FULL'),'--d8',str(r/'D8_FULL'),'--d9',str(r/'D9_LOS_QUALITY')])]
rec=[]
for name,script,args in steps:
 cmd=[sys.executable,str(d/script),'--out',str(r/name),*args];start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with (r/(name+'.log')).open('w',encoding='utf8') as f:p=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
 rec.append(dict(stage=name,command=cmd,started=start,elapsed_s=time.monotonic()-t,exit_code=p.returncode));(r/'QUALITY_VERDICT_RECEIPT.json').write_text(json.dumps(rec,indent=2));print(name,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
