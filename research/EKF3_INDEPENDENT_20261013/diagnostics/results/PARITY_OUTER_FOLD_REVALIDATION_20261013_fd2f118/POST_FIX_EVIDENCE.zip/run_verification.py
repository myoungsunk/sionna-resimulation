import subprocess,sys,json,time,datetime
from pathlib import Path
R=Path('D:/SLAM_bot/artifacts/EKF3_D6_D9_PARITY_FIX'); repo=Path('D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/checkout'); d=repo/'research/EKF3_INDEPENDENT_20261013/diagnostics'
base=['--d7',str(R/'D7_FULL'),'--d8',str(R/'D8_FULL'),'--seeds','0','--levels','1','--conditions','noise_pair']
steps=[('D7_SMOKE','d7_cir_multipath_audit.py',['--cases','R2_aA_m0']),('D7_FULL','d7_cir_multipath_audit.py',[]),('D8_FULL','d8_polarization_quality.py',['--d7',str(R/'D7_FULL')]),('D9_R5_REGRESSION','d9_quality_aware_fusion.py',base+['--cases','R5_aB_m0','--channels','full','--methods','F0_ORIGINAL','--save-trace']),('D9_7CASE','d9_quality_aware_fusion.py',base+['--methods','F0_ORIGINAL','F1_UT','F2_BIAS4']),('D9_E1_7CASE','d9_quality_aware_fusion.py',base+['--channels','full','--range-model','E1_FULL_LORO','--methods','F0_ORIGINAL'])]
rec=[]
for name,script,args in steps:
 cmd=[sys.executable,str(d/script),'--out',str(R/name),*args];t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat();print('START',name,flush=True)
 with (R/(name+'.log')).open('w',encoding='utf8') as f:p=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
 rec.append(dict(stage=name,command=cmd,started=start,elapsed_s=time.monotonic()-t,exit_code=p.returncode));(R/'EXECUTION_RECEIPT.json').write_text(json.dumps(rec,indent=2));print('END',name,p.returncode,round(time.monotonic()-t,2),flush=True)
 if p.returncode:sys.exit(p.returncode)
