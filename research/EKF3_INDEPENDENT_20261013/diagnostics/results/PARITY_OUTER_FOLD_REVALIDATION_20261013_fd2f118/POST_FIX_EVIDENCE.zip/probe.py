import sys,json,itertools
from pathlib import Path
import numpy as np
repo=Path('D:/SLAM_bot/artifacts/EKF3_P0_VERIFY_20261013_01a132b7/checkout');sys.path.insert(0,str(repo/'research/EKF3_INDEPENDENT_20261013/diagnostics'))
import d6_d9_common as c,run_d5_regimes as d5,d9_quality_aware_fusion as d9
from ekf3 import archived_direct_s_model
p=c.check_inputs();case=next(x for x in p['cases'] if x['id']=='R5_aB_m0');t,truth,ids=d5.timelines(p)['R5'];det=c.rf_case(p,case,'full',c.spectrum(p),ids);lut=c.original_lut(p);physical=det['range_raw_m']-c.B_OLD
model=archived_direct_s_model(lut,anchor_xyz_m=tuple(case['anchor']),tag_height_m=float(case['robot_z_m']),mount_deg=float(case['mount_deg']))
_,_,_,meas,_=c.case_motion(p,case,0,1,'noise_pair')
online,folds=d9.source_evidence(Path('D:/SLAM_bot/artifacts/EKF3_D6_D9_6e40ec9/D7_FULL'),Path('D:/SLAM_bot/artifacts/EKF3_D6_D9_6e40ec9/D8_FULL'))
oldinit=c.DiagnosticFilter.__init__; oldeval=d9.eval_covariance
results=[]
_,orig=d5.run_one(case,'full',1,'noise_pair',0,t,truth,ids,det,'B_OLD',physical,lut)
ref=[x for x in c.read_csv(repo/d9.REFERENCE) if x['case']==case['id'] and x['channel']=='full' and x['condition']=='noise_pair' and x['level']=='1' and x['seed']=='0' and x['range_model']=='B_OLD']
results.append({'variant':'original_D5_current','metrics':orig})
for cov,obs,metric in [(False,False,False),(True,False,False),(False,True,False),(False,False,True),(True,True,True)]:
 def init(self,*a,**kw):
  oldinit(self,*a,**kw)
  if cov:self.f.P=d5.P0_COV.copy()
 c.DiagnosticFilter.__init__=init
 if metric:
  def ev(e,P):
   x=d5.covariance_terms(e,P);return x['pose_nees'],x['yaw_nees'],x['covered95_pose']
  d9.eval_covariance=ev
 else:d9.eval_covariance=oldeval
 on={k:v.copy() for k,v in online.items()}
 if obs:
  for k in range(len(t)):on[(case['id'],'full',k)]['s_fp']=float(det['s'][k])
 rows,_=d9.run_one(case,'full','noise_pair',1,0,t,truth,ids,meas,det,physical,model,{},on,['F0_ORIGINAL'],.1,0.,False,False)
 results.append({'variant':f'cov{cov}_obs{obs}_metric{metric}','metrics':rows})
for r in results:
 r['differences']={x['arm']:float(x['mean_pose_NEES'])-float(next(v for v in ref if v['arm']==x['arm'])['mean_pose_NEES']) for x in r['metrics']}
 print(r['variant'],r['differences'])
Path('D:/SLAM_bot/artifacts/EKF3_D6_D9_PARITY_FIX/ROOT_CAUSE_ABLATION.json').write_text(json.dumps(results,indent=2))
